<?php
$gfonts_array = array(
    'ABeeZee' => array(
       'family' => 'ABeeZee',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'Abel' => array(
       'family' => 'Abel',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Abhaya Libre' => array(
       'family' => 'Abhaya Libre',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '500',
        1 => '600',
        2 => '700',
        3 => '800',
        4 => 'regular',
      ),
    ),
    'Abril Fatface' => array(
       'family' => 'Abril Fatface',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Aclonica' => array(
       'family' => 'Aclonica',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Acme' => array(
       'family' => 'Acme',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Actor' => array(
       'family' => 'Actor',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Adamina' => array(
       'family' => 'Adamina',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Advent Pro' => array(
       'family' => 'Advent Pro',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '200',
        2 => '300',
        3 => '500',
        4 => '600',
        5 => '700',
        6 => 'regular',
      ),
    ),
    'Aguafina Script' => array(
       'family' => 'Aguafina Script',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Akronim' => array(
       'family' => 'Akronim',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Aladin' => array(
       'family' => 'Aladin',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Aldrich' => array(
       'family' => 'Aldrich',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Alef' => array(
       'family' => 'Alef',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Alegreya' => array(
       'family' => 'Alegreya',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '500',
        1 => '500italic',
        2 => '700',
        3 => '700italic',
        4 => '800',
        5 => '800italic',
        6 => '900',
        7 => '900italic',
        8 => 'italic',
        9 => 'regular',
      ),
    ),
    'Alegreya SC' => array(
       'family' => 'Alegreya SC',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '500',
        1 => '500italic',
        2 => '700',
        3 => '700italic',
        4 => '800',
        5 => '800italic',
        6 => '900',
        7 => '900italic',
        8 => 'italic',
        9 => 'regular',
      ),
    ),
    'Alegreya Sans' => array(
       'family' => 'Alegreya Sans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '300',
        3 => '300italic',
        4 => '500',
        5 => '500italic',
        6 => '700',
        7 => '700italic',
        8 => '800',
        9 => '800italic',
        10 => '900',
        11 => '900italic',
        12 => 'italic',
        13 => 'regular',
      ),
    ),
    'Alegreya Sans SC' => array(
       'family' => 'Alegreya Sans SC',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '300',
        3 => '300italic',
        4 => '500',
        5 => '500italic',
        6 => '700',
        7 => '700italic',
        8 => '800',
        9 => '800italic',
        10 => '900',
        11 => '900italic',
        12 => 'italic',
        13 => 'regular',
      ),
    ),
    'Alex Brush' => array(
       'family' => 'Alex Brush',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Alfa Slab One' => array(
       'family' => 'Alfa Slab One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Alice' => array(
       'family' => 'Alice',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Alike' => array(
       'family' => 'Alike',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Alike Angular' => array(
       'family' => 'Alike Angular',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Allan' => array(
       'family' => 'Allan',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Allerta' => array(
       'family' => 'Allerta',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Allerta Stencil' => array(
       'family' => 'Allerta Stencil',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Allura' => array(
       'family' => 'Allura',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Almendra' => array(
       'family' => 'Almendra',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Almendra Display' => array(
       'family' => 'Almendra Display',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Almendra SC' => array(
       'family' => 'Almendra SC',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Amarante' => array(
       'family' => 'Amarante',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Amaranth' => array(
       'family' => 'Amaranth',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Amatic SC' => array(
       'family' => 'Amatic SC',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Amethysta' => array(
       'family' => 'Amethysta',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Amiko' => array(
       'family' => 'Amiko',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '600',
        1 => '700',
        2 => 'regular',
      ),
    ),
    'Amiri' => array(
       'family' => 'Amiri',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Amita' => array(
       'family' => 'Amita',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Anaheim' => array(
       'family' => 'Anaheim',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Andada' => array(
       'family' => 'Andada',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Andika' => array(
       'family' => 'Andika',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Angkor' => array(
       'family' => 'Angkor',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Annie Use Your Telescope' => array(
       'family' => 'Annie Use Your Telescope',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Anonymous Pro' => array(
       'family' => 'Anonymous Pro',
       'category' => 'monospace',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Antic' => array(
       'family' => 'Antic',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Antic Didone' => array(
       'family' => 'Antic Didone',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Antic Slab' => array(
       'family' => 'Antic Slab',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Anton' => array(
       'family' => 'Anton',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Arapey' => array(
       'family' => 'Arapey',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'Arbutus' => array(
       'family' => 'Arbutus',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Arbutus Slab' => array(
       'family' => 'Arbutus Slab',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Architects Daughter' => array(
       'family' => 'Architects Daughter',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Archivo' => array(
       'family' => 'Archivo',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '500',
        1 => '500italic',
        2 => '600',
        3 => '600italic',
        4 => '700',
        5 => '700italic',
        6 => 'italic',
        7 => 'regular',
      ),
    ),
    'Archivo Black' => array(
       'family' => 'Archivo Black',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Archivo Narrow' => array(
       'family' => 'Archivo Narrow',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '500',
        1 => '500italic',
        2 => '600',
        3 => '600italic',
        4 => '700',
        5 => '700italic',
        6 => 'italic',
        7 => 'regular',
      ),
    ),
    'Aref Ruqaa' => array(
       'family' => 'Aref Ruqaa',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Arima Madurai' => array(
       'family' => 'Arima Madurai',
       'category' => 'display',
       'variants' =>
     array (
        0 => '100',
        1 => '200',
        2 => '300',
        3 => '500',
        4 => '700',
        5 => '800',
        6 => '900',
        7 => 'regular',
      ),
    ),
    'Arimo' => array(
       'family' => 'Arimo',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Arizonia' => array(
       'family' => 'Arizonia',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Armata' => array(
       'family' => 'Armata',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Arsenal' => array(
       'family' => 'Arsenal',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Artifika' => array(
       'family' => 'Artifika',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Arvo' => array(
       'family' => 'Arvo',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Arya' => array(
       'family' => 'Arya',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Asap' => array(
       'family' => 'Asap',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '500',
        1 => '500italic',
        2 => '600',
        3 => '600italic',
        4 => '700',
        5 => '700italic',
        6 => 'italic',
        7 => 'regular',
      ),
    ),
    'Asap Condensed' => array(
       'family' => 'Asap Condensed',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '500',
        1 => '500italic',
        2 => '600',
        3 => '600italic',
        4 => '700',
        5 => '700italic',
        6 => 'italic',
        7 => 'regular',
      ),
    ),
    'Asar' => array(
       'family' => 'Asar',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Asset' => array(
       'family' => 'Asset',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Assistant' => array(
       'family' => 'Assistant',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '600',
        3 => '700',
        4 => '800',
        5 => 'regular',
      ),
    ),
    'Astloch' => array(
       'family' => 'Astloch',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Asul' => array(
       'family' => 'Asul',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Athiti' => array(
       'family' => 'Athiti',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '500',
        3 => '600',
        4 => '700',
        5 => 'regular',
      ),
    ),
    'Atma' => array(
       'family' => 'Atma',
       'category' => 'display',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '600',
        3 => '700',
        4 => 'regular',
      ),
    ),
    'Atomic Age' => array(
       'family' => 'Atomic Age',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Aubrey' => array(
       'family' => 'Aubrey',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Audiowide' => array(
       'family' => 'Audiowide',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Autour One' => array(
       'family' => 'Autour One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Average' => array(
       'family' => 'Average',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Average Sans' => array(
       'family' => 'Average Sans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Averia Gruesa Libre' => array(
       'family' => 'Averia Gruesa Libre',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Averia Libre' => array(
       'family' => 'Averia Libre',
       'category' => 'display',
       'variants' =>
     array (
        0 => '300',
        1 => '300italic',
        2 => '700',
        3 => '700italic',
        4 => 'italic',
        5 => 'regular',
      ),
    ),
    'Averia Sans Libre' => array(
       'family' => 'Averia Sans Libre',
       'category' => 'display',
       'variants' =>
     array (
        0 => '300',
        1 => '300italic',
        2 => '700',
        3 => '700italic',
        4 => 'italic',
        5 => 'regular',
      ),
    ),
    'Averia Serif Libre' => array(
       'family' => 'Averia Serif Libre',
       'category' => 'display',
       'variants' =>
     array (
        0 => '300',
        1 => '300italic',
        2 => '700',
        3 => '700italic',
        4 => 'italic',
        5 => 'regular',
      ),
    ),
    'Bad Script' => array(
       'family' => 'Bad Script',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Bahiana' => array(
       'family' => 'Bahiana',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Baloo' => array(
       'family' => 'Baloo',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Baloo Bhai' => array(
       'family' => 'Baloo Bhai',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Baloo Bhaijaan' => array(
       'family' => 'Baloo Bhaijaan',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Baloo Bhaina' => array(
       'family' => 'Baloo Bhaina',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Baloo Chettan' => array(
       'family' => 'Baloo Chettan',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Baloo Da' => array(
       'family' => 'Baloo Da',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Baloo Paaji' => array(
       'family' => 'Baloo Paaji',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Baloo Tamma' => array(
       'family' => 'Baloo Tamma',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Baloo Tammudu' => array(
       'family' => 'Baloo Tammudu',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Baloo Thambi' => array(
       'family' => 'Baloo Thambi',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Balthazar' => array(
       'family' => 'Balthazar',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Bangers' => array(
       'family' => 'Bangers',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Barlow' => array(
       'family' => 'Barlow',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => '800',
        13 => '800italic',
        14 => '900',
        15 => '900italic',
        16 => 'italic',
        17 => 'regular',
      ),
    ),
    'Barlow Condensed' => array(
       'family' => 'Barlow Condensed',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => '800',
        13 => '800italic',
        14 => '900',
        15 => '900italic',
        16 => 'italic',
        17 => 'regular',
      ),
    ),
    'Barlow Semi Condensed' => array(
       'family' => 'Barlow Semi Condensed',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => '800',
        13 => '800italic',
        14 => '900',
        15 => '900italic',
        16 => 'italic',
        17 => 'regular',
      ),
    ),
    'Barrio' => array(
       'family' => 'Barrio',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Basic' => array(
       'family' => 'Basic',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Battambang' => array(
       'family' => 'Battambang',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Baumans' => array(
       'family' => 'Baumans',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Bayon' => array(
       'family' => 'Bayon',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Belgrano' => array(
       'family' => 'Belgrano',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Bellefair' => array(
       'family' => 'Bellefair',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Belleza' => array(
       'family' => 'Belleza',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'BenchNine' => array(
       'family' => 'BenchNine',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '700',
        2 => 'regular',
      ),
    ),
    'Bentham' => array(
       'family' => 'Bentham',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Berkshire Swash' => array(
       'family' => 'Berkshire Swash',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Bevan' => array(
       'family' => 'Bevan',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Bigelow Rules' => array(
       'family' => 'Bigelow Rules',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Bigshot One' => array(
       'family' => 'Bigshot One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Bilbo' => array(
       'family' => 'Bilbo',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Bilbo Swash Caps' => array(
       'family' => 'Bilbo Swash Caps',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'BioRhyme' => array(
       'family' => 'BioRhyme',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '700',
        3 => '800',
        4 => 'regular',
      ),
    ),
    'BioRhyme Expanded' => array(
       'family' => 'BioRhyme Expanded',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '700',
        3 => '800',
        4 => 'regular',
      ),
    ),
    'Biryani' => array(
       'family' => 'Biryani',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '600',
        3 => '700',
        4 => '800',
        5 => '900',
        6 => 'regular',
      ),
    ),
    'Bitter' => array(
       'family' => 'Bitter',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'italic',
        2 => 'regular',
      ),
    ),
    'Black And White Picture' => array(
       'family' => 'Black And White Picture',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Black Han Sans' => array(
       'family' => 'Black Han Sans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Black Ops One' => array(
       'family' => 'Black Ops One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Bokor' => array(
       'family' => 'Bokor',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Bonbon' => array(
       'family' => 'Bonbon',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Boogaloo' => array(
       'family' => 'Boogaloo',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Bowlby One' => array(
       'family' => 'Bowlby One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Bowlby One SC' => array(
       'family' => 'Bowlby One SC',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Brawler' => array(
       'family' => 'Brawler',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Bree Serif' => array(
       'family' => 'Bree Serif',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Bubblegum Sans' => array(
       'family' => 'Bubblegum Sans',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Bubbler One' => array(
       'family' => 'Bubbler One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Buda' => array(
       'family' => 'Buda',
       'category' => 'display',
       'variants' =>
     array (
        0 => '300',
      ),
    ),
    'Buenard' => array(
       'family' => 'Buenard',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Bungee' => array(
       'family' => 'Bungee',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Bungee Hairline' => array(
       'family' => 'Bungee Hairline',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Bungee Inline' => array(
       'family' => 'Bungee Inline',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Bungee Outline' => array(
       'family' => 'Bungee Outline',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Bungee Shade' => array(
       'family' => 'Bungee Shade',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Butcherman' => array(
       'family' => 'Butcherman',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Butterfly Kids' => array(
       'family' => 'Butterfly Kids',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Cabin' => array(
       'family' => 'Cabin',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '500',
        1 => '500italic',
        2 => '600',
        3 => '600italic',
        4 => '700',
        5 => '700italic',
        6 => 'italic',
        7 => 'regular',
      ),
    ),
    'Cabin Condensed' => array(
       'family' => 'Cabin Condensed',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '500',
        1 => '600',
        2 => '700',
        3 => 'regular',
      ),
    ),
    'Cabin Sketch' => array(
       'family' => 'Cabin Sketch',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Caesar Dressing' => array(
       'family' => 'Caesar Dressing',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Cagliostro' => array(
       'family' => 'Cagliostro',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Cairo' => array(
       'family' => 'Cairo',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '600',
        3 => '700',
        4 => '900',
        5 => 'regular',
      ),
    ),
    'Calligraffitti' => array(
       'family' => 'Calligraffitti',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Cambay' => array(
       'family' => 'Cambay',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Cambo' => array(
       'family' => 'Cambo',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Candal' => array(
       'family' => 'Candal',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Cantarell' => array(
       'family' => 'Cantarell',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Cantata One' => array(
       'family' => 'Cantata One',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Cantora One' => array(
       'family' => 'Cantora One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Capriola' => array(
       'family' => 'Capriola',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Cardo' => array(
       'family' => 'Cardo',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'italic',
        2 => 'regular',
      ),
    ),
    'Carme' => array(
       'family' => 'Carme',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Carrois Gothic' => array(
       'family' => 'Carrois Gothic',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Carrois Gothic SC' => array(
       'family' => 'Carrois Gothic SC',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Carter One' => array(
       'family' => 'Carter One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Catamaran' => array(
       'family' => 'Catamaran',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '200',
        2 => '300',
        3 => '500',
        4 => '600',
        5 => '700',
        6 => '800',
        7 => '900',
        8 => 'regular',
      ),
    ),
    'Caudex' => array(
       'family' => 'Caudex',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Caveat' => array(
       'family' => 'Caveat',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Caveat Brush' => array(
       'family' => 'Caveat Brush',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Cedarville Cursive' => array(
       'family' => 'Cedarville Cursive',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Ceviche One' => array(
       'family' => 'Ceviche One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Changa' => array(
       'family' => 'Changa',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '500',
        3 => '600',
        4 => '700',
        5 => '800',
        6 => 'regular',
      ),
    ),
    'Changa One' => array(
       'family' => 'Changa One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'Chango' => array(
       'family' => 'Chango',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Chathura' => array(
       'family' => 'Chathura',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '300',
        2 => '700',
        3 => '800',
        4 => 'regular',
      ),
    ),
    'Chau Philomene One' => array(
       'family' => 'Chau Philomene One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'Chela One' => array(
       'family' => 'Chela One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Chelsea Market' => array(
       'family' => 'Chelsea Market',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Chenla' => array(
       'family' => 'Chenla',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Cherry Cream Soda' => array(
       'family' => 'Cherry Cream Soda',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Cherry Swash' => array(
       'family' => 'Cherry Swash',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Chewy' => array(
       'family' => 'Chewy',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Chicle' => array(
       'family' => 'Chicle',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Chivo' => array(
       'family' => 'Chivo',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '300italic',
        2 => '700',
        3 => '700italic',
        4 => '900',
        5 => '900italic',
        6 => 'italic',
        7 => 'regular',
      ),
    ),
    'Chonburi' => array(
       'family' => 'Chonburi',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Cinzel' => array(
       'family' => 'Cinzel',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => '900',
        2 => 'regular',
      ),
    ),
    'Cinzel Decorative' => array(
       'family' => 'Cinzel Decorative',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => '900',
        2 => 'regular',
      ),
    ),
    'Clicker Script' => array(
       'family' => 'Clicker Script',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Coda' => array(
       'family' => 'Coda',
       'category' => 'display',
       'variants' =>
     array (
        0 => '800',
        1 => 'regular',
      ),
    ),
    'Coda Caption' => array(
       'family' => 'Coda Caption',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '800',
      ),
    ),
    'Codystar' => array(
       'family' => 'Codystar',
       'category' => 'display',
       'variants' =>
     array (
        0 => '300',
        1 => 'regular',
      ),
    ),
    'Coiny' => array(
       'family' => 'Coiny',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Combo' => array(
       'family' => 'Combo',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Comfortaa' => array(
       'family' => 'Comfortaa',
       'category' => 'display',
       'variants' =>
     array (
        0 => '300',
        1 => '700',
        2 => 'regular',
      ),
    ),
    'Coming Soon' => array(
       'family' => 'Coming Soon',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Concert One' => array(
       'family' => 'Concert One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Condiment' => array(
       'family' => 'Condiment',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Content' => array(
       'family' => 'Content',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Contrail One' => array(
       'family' => 'Contrail One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Convergence' => array(
       'family' => 'Convergence',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Cookie' => array(
       'family' => 'Cookie',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Copse' => array(
       'family' => 'Copse',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Corben' => array(
       'family' => 'Corben',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Cormorant' => array(
       'family' => 'Cormorant',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '300',
        1 => '300italic',
        2 => '500',
        3 => '500italic',
        4 => '600',
        5 => '600italic',
        6 => '700',
        7 => '700italic',
        8 => 'italic',
        9 => 'regular',
      ),
    ),
    'Cormorant Garamond' => array(
       'family' => 'Cormorant Garamond',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '300',
        1 => '300italic',
        2 => '500',
        3 => '500italic',
        4 => '600',
        5 => '600italic',
        6 => '700',
        7 => '700italic',
        8 => 'italic',
        9 => 'regular',
      ),
    ),
    'Cormorant Infant' => array(
       'family' => 'Cormorant Infant',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '300',
        1 => '300italic',
        2 => '500',
        3 => '500italic',
        4 => '600',
        5 => '600italic',
        6 => '700',
        7 => '700italic',
        8 => 'italic',
        9 => 'regular',
      ),
    ),
    'Cormorant SC' => array(
       'family' => 'Cormorant SC',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '600',
        3 => '700',
        4 => 'regular',
      ),
    ),
    'Cormorant Unicase' => array(
       'family' => 'Cormorant Unicase',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '600',
        3 => '700',
        4 => 'regular',
      ),
    ),
    'Cormorant Upright' => array(
       'family' => 'Cormorant Upright',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '600',
        3 => '700',
        4 => 'regular',
      ),
    ),
    'Courgette' => array(
       'family' => 'Courgette',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Cousine' => array(
       'family' => 'Cousine',
       'category' => 'monospace',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Coustard' => array(
       'family' => 'Coustard',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '900',
        1 => 'regular',
      ),
    ),
    'Covered By Your Grace' => array(
       'family' => 'Covered By Your Grace',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Crafty Girls' => array(
       'family' => 'Crafty Girls',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Creepster' => array(
       'family' => 'Creepster',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Crete Round' => array(
       'family' => 'Crete Round',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'Crimson Text' => array(
       'family' => 'Crimson Text',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '600',
        1 => '600italic',
        2 => '700',
        3 => '700italic',
        4 => 'italic',
        5 => 'regular',
      ),
    ),
    'Croissant One' => array(
       'family' => 'Croissant One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Crushed' => array(
       'family' => 'Crushed',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Cuprum' => array(
       'family' => 'Cuprum',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Cute Font' => array(
       'family' => 'Cute Font',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Cutive' => array(
       'family' => 'Cutive',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Cutive Mono' => array(
       'family' => 'Cutive Mono',
       'category' => 'monospace',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Damion' => array(
       'family' => 'Damion',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Dancing Script' => array(
       'family' => 'Dancing Script',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Dangrek' => array(
       'family' => 'Dangrek',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'David Libre' => array(
       'family' => 'David Libre',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '500',
        1 => '700',
        2 => 'regular',
      ),
    ),
    'Dawning of a New Day' => array(
       'family' => 'Dawning of a New Day',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Days One' => array(
       'family' => 'Days One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Dekko' => array(
       'family' => 'Dekko',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Delius' => array(
       'family' => 'Delius',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Delius Swash Caps' => array(
       'family' => 'Delius Swash Caps',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Delius Unicase' => array(
       'family' => 'Delius Unicase',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Della Respira' => array(
       'family' => 'Della Respira',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Denk One' => array(
       'family' => 'Denk One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Devonshire' => array(
       'family' => 'Devonshire',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Dhurjati' => array(
       'family' => 'Dhurjati',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Didact Gothic' => array(
       'family' => 'Didact Gothic',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Diplomata' => array(
       'family' => 'Diplomata',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Diplomata SC' => array(
       'family' => 'Diplomata SC',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Do Hyeon' => array(
       'family' => 'Do Hyeon',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Dokdo' => array(
       'family' => 'Dokdo',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Domine' => array(
       'family' => 'Domine',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Donegal One' => array(
       'family' => 'Donegal One',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Doppio One' => array(
       'family' => 'Doppio One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Dorsa' => array(
       'family' => 'Dorsa',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Dosis' => array(
       'family' => 'Dosis',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '500',
        3 => '600',
        4 => '700',
        5 => '800',
        6 => 'regular',
      ),
    ),
    'Dr Sugiyama' => array(
       'family' => 'Dr Sugiyama',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Duru Sans' => array(
       'family' => 'Duru Sans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Dynalight' => array(
       'family' => 'Dynalight',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'EB Garamond' => array(
       'family' => 'EB Garamond',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '500',
        1 => '500italic',
        2 => '600',
        3 => '600italic',
        4 => '700',
        5 => '700italic',
        6 => '800',
        7 => '800italic',
        8 => 'italic',
        9 => 'regular',
      ),
    ),
    'Eagle Lake' => array(
       'family' => 'Eagle Lake',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'East Sea Dokdo' => array(
       'family' => 'East Sea Dokdo',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Eater' => array(
       'family' => 'Eater',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Economica' => array(
       'family' => 'Economica',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Eczar' => array(
       'family' => 'Eczar',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '500',
        1 => '600',
        2 => '700',
        3 => '800',
        4 => 'regular',
      ),
    ),
    'El Messiri' => array(
       'family' => 'El Messiri',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '500',
        1 => '600',
        2 => '700',
        3 => 'regular',
      ),
    ),
    'Electrolize' => array(
       'family' => 'Electrolize',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Elsie' => array(
       'family' => 'Elsie',
       'category' => 'display',
       'variants' =>
     array (
        0 => '900',
        1 => 'regular',
      ),
    ),
    'Elsie Swash Caps' => array(
       'family' => 'Elsie Swash Caps',
       'category' => 'display',
       'variants' =>
     array (
        0 => '900',
        1 => 'regular',
      ),
    ),
    'Emblema One' => array(
       'family' => 'Emblema One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Emilys Candy' => array(
       'family' => 'Emilys Candy',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Encode Sans' => array(
       'family' => 'Encode Sans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '200',
        2 => '300',
        3 => '500',
        4 => '600',
        5 => '700',
        6 => '800',
        7 => '900',
        8 => 'regular',
      ),
    ),
    'Encode Sans Condensed' => array(
       'family' => 'Encode Sans Condensed',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '200',
        2 => '300',
        3 => '500',
        4 => '600',
        5 => '700',
        6 => '800',
        7 => '900',
        8 => 'regular',
      ),
    ),
    'Encode Sans Expanded' => array(
       'family' => 'Encode Sans Expanded',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '200',
        2 => '300',
        3 => '500',
        4 => '600',
        5 => '700',
        6 => '800',
        7 => '900',
        8 => 'regular',
      ),
    ),
    'Encode Sans Semi Condensed' => array(
       'family' => 'Encode Sans Semi Condensed',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '200',
        2 => '300',
        3 => '500',
        4 => '600',
        5 => '700',
        6 => '800',
        7 => '900',
        8 => 'regular',
      ),
    ),
    'Encode Sans Semi Expanded' => array(
       'family' => 'Encode Sans Semi Expanded',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '200',
        2 => '300',
        3 => '500',
        4 => '600',
        5 => '700',
        6 => '800',
        7 => '900',
        8 => 'regular',
      ),
    ),
    'Engagement' => array(
       'family' => 'Engagement',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Englebert' => array(
       'family' => 'Englebert',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Enriqueta' => array(
       'family' => 'Enriqueta',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Erica One' => array(
       'family' => 'Erica One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Esteban' => array(
       'family' => 'Esteban',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Euphoria Script' => array(
       'family' => 'Euphoria Script',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Ewert' => array(
       'family' => 'Ewert',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Exo' => array(
       'family' => 'Exo',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => '800',
        13 => '800italic',
        14 => '900',
        15 => '900italic',
        16 => 'italic',
        17 => 'regular',
      ),
    ),
    'Exo 2' => array(
       'family' => 'Exo 2',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => '800',
        13 => '800italic',
        14 => '900',
        15 => '900italic',
        16 => 'italic',
        17 => 'regular',
      ),
    ),
    'Expletus Sans' => array(
       'family' => 'Expletus Sans',
       'category' => 'display',
       'variants' =>
     array (
        0 => '500',
        1 => '500italic',
        2 => '600',
        3 => '600italic',
        4 => '700',
        5 => '700italic',
        6 => 'italic',
        7 => 'regular',
      ),
    ),
    'Fanwood Text' => array(
       'family' => 'Fanwood Text',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'Farsan' => array(
       'family' => 'Farsan',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Fascinate' => array(
       'family' => 'Fascinate',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Fascinate Inline' => array(
       'family' => 'Fascinate Inline',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Faster One' => array(
       'family' => 'Faster One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Fasthand' => array(
       'family' => 'Fasthand',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Fauna One' => array(
       'family' => 'Fauna One',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Faustina' => array(
       'family' => 'Faustina',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '500',
        1 => '500italic',
        2 => '600',
        3 => '600italic',
        4 => '700',
        5 => '700italic',
        6 => 'italic',
        7 => 'regular',
      ),
    ),
    'Federant' => array(
       'family' => 'Federant',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Federo' => array(
       'family' => 'Federo',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Felipa' => array(
       'family' => 'Felipa',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Fenix' => array(
       'family' => 'Fenix',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Finger Paint' => array(
       'family' => 'Finger Paint',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Fira Mono' => array(
       'family' => 'Fira Mono',
       'category' => 'monospace',
       'variants' =>
     array (
        0 => '500',
        1 => '700',
        2 => 'regular',
      ),
    ),
    'Fira Sans' => array(
       'family' => 'Fira Sans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => '800',
        13 => '800italic',
        14 => '900',
        15 => '900italic',
        16 => 'italic',
        17 => 'regular',
      ),
    ),
    'Fira Sans Condensed' => array(
       'family' => 'Fira Sans Condensed',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => '800',
        13 => '800italic',
        14 => '900',
        15 => '900italic',
        16 => 'italic',
        17 => 'regular',
      ),
    ),
    'Fira Sans Extra Condensed' => array(
       'family' => 'Fira Sans Extra Condensed',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => '800',
        13 => '800italic',
        14 => '900',
        15 => '900italic',
        16 => 'italic',
        17 => 'regular',
      ),
    ),
    'Fjalla One' => array(
       'family' => 'Fjalla One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Fjord One' => array(
       'family' => 'Fjord One',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Flamenco' => array(
       'family' => 'Flamenco',
       'category' => 'display',
       'variants' =>
     array (
        0 => '300',
        1 => 'regular',
      ),
    ),
    'Flavors' => array(
       'family' => 'Flavors',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Fondamento' => array(
       'family' => 'Fondamento',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'Fontdiner Swanky' => array(
       'family' => 'Fontdiner Swanky',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Forum' => array(
       'family' => 'Forum',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Francois One' => array(
       'family' => 'Francois One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Frank Ruhl Libre' => array(
       'family' => 'Frank Ruhl Libre',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '700',
        3 => '900',
        4 => 'regular',
      ),
    ),
    'Freckle Face' => array(
       'family' => 'Freckle Face',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Fredericka the Great' => array(
       'family' => 'Fredericka the Great',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Fredoka One' => array(
       'family' => 'Fredoka One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Freehand' => array(
       'family' => 'Freehand',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Fresca' => array(
       'family' => 'Fresca',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Frijole' => array(
       'family' => 'Frijole',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Fruktur' => array(
       'family' => 'Fruktur',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Fugaz One' => array(
       'family' => 'Fugaz One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'GFS Didot' => array(
       'family' => 'GFS Didot',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'GFS Neohellenic' => array(
       'family' => 'GFS Neohellenic',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Gabriela' => array(
       'family' => 'Gabriela',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Gaegu' => array(
       'family' => 'Gaegu',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => '300',
        1 => '700',
        2 => 'regular',
      ),
    ),
    'Gafata' => array(
       'family' => 'Gafata',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Galada' => array(
       'family' => 'Galada',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Galdeano' => array(
       'family' => 'Galdeano',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Galindo' => array(
       'family' => 'Galindo',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Gamja Flower' => array(
       'family' => 'Gamja Flower',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Gentium Basic' => array(
       'family' => 'Gentium Basic',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Gentium Book Basic' => array(
       'family' => 'Gentium Book Basic',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Geo' => array(
       'family' => 'Geo',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'Geostar' => array(
       'family' => 'Geostar',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Geostar Fill' => array(
       'family' => 'Geostar Fill',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Germania One' => array(
       'family' => 'Germania One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Gidugu' => array(
       'family' => 'Gidugu',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Gilda Display' => array(
       'family' => 'Gilda Display',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Give You Glory' => array(
       'family' => 'Give You Glory',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Glass Antiqua' => array(
       'family' => 'Glass Antiqua',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Glegoo' => array(
       'family' => 'Glegoo',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Gloria Hallelujah' => array(
       'family' => 'Gloria Hallelujah',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Goblin One' => array(
       'family' => 'Goblin One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Gochi Hand' => array(
       'family' => 'Gochi Hand',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Gorditas' => array(
       'family' => 'Gorditas',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Gothic A1' => array(
       'family' => 'Gothic A1',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '200',
        2 => '300',
        3 => '500',
        4 => '600',
        5 => '700',
        6 => '800',
        7 => '900',
        8 => 'regular',
      ),
    ),
    'Goudy Bookletter 1911' => array(
       'family' => 'Goudy Bookletter 1911',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Graduate' => array(
       'family' => 'Graduate',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Grand Hotel' => array(
       'family' => 'Grand Hotel',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Gravitas One' => array(
       'family' => 'Gravitas One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Great Vibes' => array(
       'family' => 'Great Vibes',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Griffy' => array(
       'family' => 'Griffy',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Gruppo' => array(
       'family' => 'Gruppo',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Gudea' => array(
       'family' => 'Gudea',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'italic',
        2 => 'regular',
      ),
    ),
    'Gugi' => array(
       'family' => 'Gugi',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Gurajada' => array(
       'family' => 'Gurajada',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Habibi' => array(
       'family' => 'Habibi',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Halant' => array(
       'family' => 'Halant',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '600',
        3 => '700',
        4 => 'regular',
      ),
    ),
    'Hammersmith One' => array(
       'family' => 'Hammersmith One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Hanalei' => array(
       'family' => 'Hanalei',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Hanalei Fill' => array(
       'family' => 'Hanalei Fill',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Handlee' => array(
       'family' => 'Handlee',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Hanuman' => array(
       'family' => 'Hanuman',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Happy Monkey' => array(
       'family' => 'Happy Monkey',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Harmattan' => array(
       'family' => 'Harmattan',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Headland One' => array(
       'family' => 'Headland One',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Heebo' => array(
       'family' => 'Heebo',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '300',
        2 => '500',
        3 => '700',
        4 => '800',
        5 => '900',
        6 => 'regular',
      ),
    ),
    'Henny Penny' => array(
       'family' => 'Henny Penny',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Herr Von Muellerhoff' => array(
       'family' => 'Herr Von Muellerhoff',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Hi Melody' => array(
       'family' => 'Hi Melody',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Hind' => array(
       'family' => 'Hind',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '600',
        3 => '700',
        4 => 'regular',
      ),
    ),
    'Hind Guntur' => array(
       'family' => 'Hind Guntur',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '600',
        3 => '700',
        4 => 'regular',
      ),
    ),
    'Hind Madurai' => array(
       'family' => 'Hind Madurai',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '600',
        3 => '700',
        4 => 'regular',
      ),
    ),
    'Hind Siliguri' => array(
       'family' => 'Hind Siliguri',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '600',
        3 => '700',
        4 => 'regular',
      ),
    ),
    'Hind Vadodara' => array(
       'family' => 'Hind Vadodara',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '600',
        3 => '700',
        4 => 'regular',
      ),
    ),
    'Holtwood One SC' => array(
       'family' => 'Holtwood One SC',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Homemade Apple' => array(
       'family' => 'Homemade Apple',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Homenaje' => array(
       'family' => 'Homenaje',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'IBM Plex Mono' => array(
       'family' => 'IBM Plex Mono',
       'category' => 'monospace',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => 'italic',
        13 => 'regular',
      ),
    ),
    'IBM Plex Sans' => array(
       'family' => 'IBM Plex Sans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => 'italic',
        13 => 'regular',
      ),
    ),
    'IBM Plex Sans Condensed' => array(
       'family' => 'IBM Plex Sans Condensed',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => 'italic',
        13 => 'regular',
      ),
    ),
    'IBM Plex Serif' => array(
       'family' => 'IBM Plex Serif',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => 'italic',
        13 => 'regular',
      ),
    ),
    'IM Fell DW Pica' => array(
       'family' => 'IM Fell DW Pica',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'IM Fell DW Pica SC' => array(
       'family' => 'IM Fell DW Pica SC',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'IM Fell Double Pica' => array(
       'family' => 'IM Fell Double Pica',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'IM Fell Double Pica SC' => array(
       'family' => 'IM Fell Double Pica SC',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'IM Fell English' => array(
       'family' => 'IM Fell English',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'IM Fell English SC' => array(
       'family' => 'IM Fell English SC',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'IM Fell French Canon' => array(
       'family' => 'IM Fell French Canon',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'IM Fell French Canon SC' => array(
       'family' => 'IM Fell French Canon SC',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'IM Fell Great Primer' => array(
       'family' => 'IM Fell Great Primer',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'IM Fell Great Primer SC' => array(
       'family' => 'IM Fell Great Primer SC',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Iceberg' => array(
       'family' => 'Iceberg',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Iceland' => array(
       'family' => 'Iceland',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Imprima' => array(
       'family' => 'Imprima',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Inconsolata' => array(
       'family' => 'Inconsolata',
       'category' => 'monospace',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Inder' => array(
       'family' => 'Inder',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Indie Flower' => array(
       'family' => 'Indie Flower',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Inika' => array(
       'family' => 'Inika',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Inknut Antiqua' => array(
       'family' => 'Inknut Antiqua',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '600',
        3 => '700',
        4 => '800',
        5 => '900',
        6 => 'regular',
      ),
    ),
    'Irish Grover' => array(
       'family' => 'Irish Grover',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Istok Web' => array(
       'family' => 'Istok Web',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Italiana' => array(
       'family' => 'Italiana',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Italianno' => array(
       'family' => 'Italianno',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Itim' => array(
       'family' => 'Itim',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Jacques Francois' => array(
       'family' => 'Jacques Francois',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Jacques Francois Shadow' => array(
       'family' => 'Jacques Francois Shadow',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Jaldi' => array(
       'family' => 'Jaldi',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Jim Nightshade' => array(
       'family' => 'Jim Nightshade',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Jockey One' => array(
       'family' => 'Jockey One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Jolly Lodger' => array(
       'family' => 'Jolly Lodger',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Jomhuria' => array(
       'family' => 'Jomhuria',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Josefin Sans' => array(
       'family' => 'Josefin Sans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '300',
        3 => '300italic',
        4 => '600',
        5 => '600italic',
        6 => '700',
        7 => '700italic',
        8 => 'italic',
        9 => 'regular',
      ),
    ),
    'Josefin Slab' => array(
       'family' => 'Josefin Slab',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '300',
        3 => '300italic',
        4 => '600',
        5 => '600italic',
        6 => '700',
        7 => '700italic',
        8 => 'italic',
        9 => 'regular',
      ),
    ),
    'Joti One' => array(
       'family' => 'Joti One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Jua' => array(
       'family' => 'Jua',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Judson' => array(
       'family' => 'Judson',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'italic',
        2 => 'regular',
      ),
    ),
    'Julee' => array(
       'family' => 'Julee',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Julius Sans One' => array(
       'family' => 'Julius Sans One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Junge' => array(
       'family' => 'Junge',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Jura' => array(
       'family' => 'Jura',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '600',
        3 => '700',
        4 => 'regular',
      ),
    ),
    'Just Another Hand' => array(
       'family' => 'Just Another Hand',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Just Me Again Down Here' => array(
       'family' => 'Just Me Again Down Here',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Kadwa' => array(
       'family' => 'Kadwa',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Kalam' => array(
       'family' => 'Kalam',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => '300',
        1 => '700',
        2 => 'regular',
      ),
    ),
    'Kameron' => array(
       'family' => 'Kameron',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Kanit' => array(
       'family' => 'Kanit',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => '800',
        13 => '800italic',
        14 => '900',
        15 => '900italic',
        16 => 'italic',
        17 => 'regular',
      ),
    ),
    'Kantumruy' => array(
       'family' => 'Kantumruy',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '700',
        2 => 'regular',
      ),
    ),
    'Karla' => array(
       'family' => 'Karla',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Karma' => array(
       'family' => 'Karma',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '600',
        3 => '700',
        4 => 'regular',
      ),
    ),
    'Katibeh' => array(
       'family' => 'Katibeh',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Kaushan Script' => array(
       'family' => 'Kaushan Script',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Kavivanar' => array(
       'family' => 'Kavivanar',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Kavoon' => array(
       'family' => 'Kavoon',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Kdam Thmor' => array(
       'family' => 'Kdam Thmor',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Keania One' => array(
       'family' => 'Keania One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Kelly Slab' => array(
       'family' => 'Kelly Slab',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Kenia' => array(
       'family' => 'Kenia',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Khand' => array(
       'family' => 'Khand',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '600',
        3 => '700',
        4 => 'regular',
      ),
    ),
    'Khmer' => array(
       'family' => 'Khmer',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Khula' => array(
       'family' => 'Khula',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '600',
        2 => '700',
        3 => '800',
        4 => 'regular',
      ),
    ),
    'Kirang Haerang' => array(
       'family' => 'Kirang Haerang',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Kite One' => array(
       'family' => 'Kite One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Knewave' => array(
       'family' => 'Knewave',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Kosugi' => array(
       'family' => 'Kosugi',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Kosugi Maru' => array(
       'family' => 'Kosugi Maru',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Kotta One' => array(
       'family' => 'Kotta One',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Koulen' => array(
       'family' => 'Koulen',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Kranky' => array(
       'family' => 'Kranky',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Kreon' => array(
       'family' => 'Kreon',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '300',
        1 => '700',
        2 => 'regular',
      ),
    ),
    'Kristi' => array(
       'family' => 'Kristi',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Krona One' => array(
       'family' => 'Krona One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Kumar One' => array(
       'family' => 'Kumar One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Kumar One Outline' => array(
       'family' => 'Kumar One Outline',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Kurale' => array(
       'family' => 'Kurale',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'La Belle Aurore' => array(
       'family' => 'La Belle Aurore',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Laila' => array(
       'family' => 'Laila',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '600',
        3 => '700',
        4 => 'regular',
      ),
    ),
    'Lakki Reddy' => array(
       'family' => 'Lakki Reddy',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Lalezar' => array(
       'family' => 'Lalezar',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Lancelot' => array(
       'family' => 'Lancelot',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Lateef' => array(
       'family' => 'Lateef',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Lato' => array(
       'family' => 'Lato',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '300',
        3 => '300italic',
        4 => '700',
        5 => '700italic',
        6 => '900',
        7 => '900italic',
        8 => 'italic',
        9 => 'regular',
      ),
    ),
    'League Script' => array(
       'family' => 'League Script',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Leckerli One' => array(
       'family' => 'Leckerli One',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Ledger' => array(
       'family' => 'Ledger',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Lekton' => array(
       'family' => 'Lekton',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'italic',
        2 => 'regular',
      ),
    ),
    'Lemon' => array(
       'family' => 'Lemon',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Lemonada' => array(
       'family' => 'Lemonada',
       'category' => 'display',
       'variants' =>
     array (
        0 => '300',
        1 => '600',
        2 => '700',
        3 => 'regular',
      ),
    ),
    'Libre Barcode 128' => array(
       'family' => 'Libre Barcode 128',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Libre Barcode 128 Text' => array(
       'family' => 'Libre Barcode 128 Text',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Libre Barcode 39' => array(
       'family' => 'Libre Barcode 39',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Libre Barcode 39 Extended' => array(
       'family' => 'Libre Barcode 39 Extended',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Libre Barcode 39 Extended Text' => array(
       'family' => 'Libre Barcode 39 Extended Text',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Libre Barcode 39 Text' => array(
       'family' => 'Libre Barcode 39 Text',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Libre Baskerville' => array(
       'family' => 'Libre Baskerville',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'italic',
        2 => 'regular',
      ),
    ),
    'Libre Franklin' => array(
       'family' => 'Libre Franklin',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => '800',
        13 => '800italic',
        14 => '900',
        15 => '900italic',
        16 => 'italic',
        17 => 'regular',
      ),
    ),
    'Life Savers' => array(
       'family' => 'Life Savers',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Lilita One' => array(
       'family' => 'Lilita One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Lily Script One' => array(
       'family' => 'Lily Script One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Limelight' => array(
       'family' => 'Limelight',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Linden Hill' => array(
       'family' => 'Linden Hill',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'Lobster' => array(
       'family' => 'Lobster',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Lobster Two' => array(
       'family' => 'Lobster Two',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Londrina Outline' => array(
       'family' => 'Londrina Outline',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Londrina Shadow' => array(
       'family' => 'Londrina Shadow',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Londrina Sketch' => array(
       'family' => 'Londrina Sketch',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Londrina Solid' => array(
       'family' => 'Londrina Solid',
       'category' => 'display',
       'variants' =>
     array (
        0 => '100',
        1 => '300',
        2 => '900',
        3 => 'regular',
      ),
    ),
    'Lora' => array(
       'family' => 'Lora',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Love Ya Like A Sister' => array(
       'family' => 'Love Ya Like A Sister',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Loved by the King' => array(
       'family' => 'Loved by the King',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Lovers Quarrel' => array(
       'family' => 'Lovers Quarrel',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Luckiest Guy' => array(
       'family' => 'Luckiest Guy',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Lusitana' => array(
       'family' => 'Lusitana',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Lustria' => array(
       'family' => 'Lustria',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'M PLUS 1p' => array(
       'family' => 'M PLUS 1p',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '300',
        2 => '500',
        3 => '700',
        4 => '800',
        5 => '900',
        6 => 'regular',
      ),
    ),
    'M PLUS Rounded 1c' => array(
       'family' => 'M PLUS Rounded 1c',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '300',
        2 => '500',
        3 => '700',
        4 => '800',
        5 => '900',
        6 => 'regular',
      ),
    ),
    'Macondo' => array(
       'family' => 'Macondo',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Macondo Swash Caps' => array(
       'family' => 'Macondo Swash Caps',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Mada' => array(
       'family' => 'Mada',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '500',
        3 => '600',
        4 => '700',
        5 => '900',
        6 => 'regular',
      ),
    ),
    'Magra' => array(
       'family' => 'Magra',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Maiden Orange' => array(
       'family' => 'Maiden Orange',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Maitree' => array(
       'family' => 'Maitree',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '500',
        3 => '600',
        4 => '700',
        5 => 'regular',
      ),
    ),
    'Mako' => array(
       'family' => 'Mako',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Mallanna' => array(
       'family' => 'Mallanna',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Mandali' => array(
       'family' => 'Mandali',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Manuale' => array(
       'family' => 'Manuale',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '500',
        1 => '500italic',
        2 => '600',
        3 => '600italic',
        4 => '700',
        5 => '700italic',
        6 => 'italic',
        7 => 'regular',
      ),
    ),
    'Marcellus' => array(
       'family' => 'Marcellus',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Marcellus SC' => array(
       'family' => 'Marcellus SC',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Marck Script' => array(
       'family' => 'Marck Script',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Margarine' => array(
       'family' => 'Margarine',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Markazi Text' => array(
       'family' => 'Markazi Text',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '500',
        1 => '600',
        2 => '700',
        3 => 'regular',
      ),
    ),
    'Marko One' => array(
       'family' => 'Marko One',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Marmelad' => array(
       'family' => 'Marmelad',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Martel' => array(
       'family' => 'Martel',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '600',
        3 => '700',
        4 => '800',
        5 => '900',
        6 => 'regular',
      ),
    ),
    'Martel Sans' => array(
       'family' => 'Martel Sans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '600',
        3 => '700',
        4 => '800',
        5 => '900',
        6 => 'regular',
      ),
    ),
    'Marvel' => array(
       'family' => 'Marvel',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Mate' => array(
       'family' => 'Mate',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'Mate SC' => array(
       'family' => 'Mate SC',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Maven Pro' => array(
       'family' => 'Maven Pro',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '500',
        1 => '700',
        2 => '900',
        3 => 'regular',
      ),
    ),
    'McLaren' => array(
       'family' => 'McLaren',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Meddon' => array(
       'family' => 'Meddon',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'MedievalSharp' => array(
       'family' => 'MedievalSharp',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Medula One' => array(
       'family' => 'Medula One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Meera Inimai' => array(
       'family' => 'Meera Inimai',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Megrim' => array(
       'family' => 'Megrim',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Meie Script' => array(
       'family' => 'Meie Script',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Merienda' => array(
       'family' => 'Merienda',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Merienda One' => array(
       'family' => 'Merienda One',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Merriweather' => array(
       'family' => 'Merriweather',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '300',
        1 => '300italic',
        2 => '700',
        3 => '700italic',
        4 => '900',
        5 => '900italic',
        6 => 'italic',
        7 => 'regular',
      ),
    ),
    'Merriweather Sans' => array(
       'family' => 'Merriweather Sans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '300italic',
        2 => '700',
        3 => '700italic',
        4 => '800',
        5 => '800italic',
        6 => 'italic',
        7 => 'regular',
      ),
    ),
    'Metal' => array(
       'family' => 'Metal',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Metal Mania' => array(
       'family' => 'Metal Mania',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Metamorphous' => array(
       'family' => 'Metamorphous',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Metrophobic' => array(
       'family' => 'Metrophobic',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Michroma' => array(
       'family' => 'Michroma',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Milonga' => array(
       'family' => 'Milonga',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Miltonian' => array(
       'family' => 'Miltonian',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Miltonian Tattoo' => array(
       'family' => 'Miltonian Tattoo',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Mina' => array(
       'family' => 'Mina',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Miniver' => array(
       'family' => 'Miniver',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Miriam Libre' => array(
       'family' => 'Miriam Libre',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Mirza' => array(
       'family' => 'Mirza',
       'category' => 'display',
       'variants' =>
     array (
        0 => '500',
        1 => '600',
        2 => '700',
        3 => 'regular',
      ),
    ),
    'Miss Fajardose' => array(
       'family' => 'Miss Fajardose',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Mitr' => array(
       'family' => 'Mitr',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '500',
        3 => '600',
        4 => '700',
        5 => 'regular',
      ),
    ),
    'Modak' => array(
       'family' => 'Modak',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Modern Antiqua' => array(
       'family' => 'Modern Antiqua',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Mogra' => array(
       'family' => 'Mogra',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Molengo' => array(
       'family' => 'Molengo',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Molle' => array(
       'family' => 'Molle',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'italic',
      ),
    ),
    'Monda' => array(
       'family' => 'Monda',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Monofett' => array(
       'family' => 'Monofett',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Monoton' => array(
       'family' => 'Monoton',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Monsieur La Doulaise' => array(
       'family' => 'Monsieur La Doulaise',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Montaga' => array(
       'family' => 'Montaga',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Montez' => array(
       'family' => 'Montez',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Montserrat' => array(
       'family' => 'Montserrat',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => '800',
        13 => '800italic',
        14 => '900',
        15 => '900italic',
        16 => 'italic',
        17 => 'regular',
      ),
    ),
    'Montserrat Alternates' => array(
       'family' => 'Montserrat Alternates',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => '800',
        13 => '800italic',
        14 => '900',
        15 => '900italic',
        16 => 'italic',
        17 => 'regular',
      ),
    ),
    'Montserrat Subrayada' => array(
       'family' => 'Montserrat Subrayada',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Moul' => array(
       'family' => 'Moul',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Moulpali' => array(
       'family' => 'Moulpali',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Mountains of Christmas' => array(
       'family' => 'Mountains of Christmas',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Mouse Memoirs' => array(
       'family' => 'Mouse Memoirs',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Mr Bedfort' => array(
       'family' => 'Mr Bedfort',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Mr Dafoe' => array(
       'family' => 'Mr Dafoe',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Mr De Haviland' => array(
       'family' => 'Mr De Haviland',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Mrs Saint Delafield' => array(
       'family' => 'Mrs Saint Delafield',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Mrs Sheppards' => array(
       'family' => 'Mrs Sheppards',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Mukta' => array(
       'family' => 'Mukta',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '500',
        3 => '600',
        4 => '700',
        5 => '800',
        6 => 'regular',
      ),
    ),
    'Mukta Mahee' => array(
       'family' => 'Mukta Mahee',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '500',
        3 => '600',
        4 => '700',
        5 => '800',
        6 => 'regular',
      ),
    ),
    'Mukta Malar' => array(
       'family' => 'Mukta Malar',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '500',
        3 => '600',
        4 => '700',
        5 => '800',
        6 => 'regular',
      ),
    ),
    'Mukta Vaani' => array(
       'family' => 'Mukta Vaani',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '500',
        3 => '600',
        4 => '700',
        5 => '800',
        6 => 'regular',
      ),
    ),
    'Muli' => array(
       'family' => 'Muli',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '200italic',
        2 => '300',
        3 => '300italic',
        4 => '600',
        5 => '600italic',
        6 => '700',
        7 => '700italic',
        8 => '800',
        9 => '800italic',
        10 => '900',
        11 => '900italic',
        12 => 'italic',
        13 => 'regular',
      ),
    ),
    'Mystery Quest' => array(
       'family' => 'Mystery Quest',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'NTR' => array(
       'family' => 'NTR',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Nanum Brush Script' => array(
       'family' => 'Nanum Brush Script',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Nanum Gothic' => array(
       'family' => 'Nanum Gothic',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '800',
        2 => 'regular',
      ),
    ),
    'Nanum Gothic Coding' => array(
       'family' => 'Nanum Gothic Coding',
       'category' => 'monospace',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Nanum Myeongjo' => array(
       'family' => 'Nanum Myeongjo',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => '800',
        2 => 'regular',
      ),
    ),
    'Nanum Pen Script' => array(
       'family' => 'Nanum Pen Script',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Neucha' => array(
       'family' => 'Neucha',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Neuton' => array(
       'family' => 'Neuton',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '700',
        3 => '800',
        4 => 'italic',
        5 => 'regular',
      ),
    ),
    'New Rocker' => array(
       'family' => 'New Rocker',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'News Cycle' => array(
       'family' => 'News Cycle',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Niconne' => array(
       'family' => 'Niconne',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Nixie One' => array(
       'family' => 'Nixie One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Nobile' => array(
       'family' => 'Nobile',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '500',
        1 => '500italic',
        2 => '700',
        3 => '700italic',
        4 => 'italic',
        5 => 'regular',
      ),
    ),
    'Nokora' => array(
       'family' => 'Nokora',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Norican' => array(
       'family' => 'Norican',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Nosifer' => array(
       'family' => 'Nosifer',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Nothing You Could Do' => array(
       'family' => 'Nothing You Could Do',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Noticia Text' => array(
       'family' => 'Noticia Text',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Noto Sans' => array(
       'family' => 'Noto Sans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Noto Sans JP' => array(
       'family' => 'Noto Sans JP',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '300',
        2 => '500',
        3 => '700',
        4 => '900',
        5 => 'regular',
      ),
    ),
    'Noto Sans KR' => array(
       'family' => 'Noto Sans KR',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '300',
        2 => '500',
        3 => '700',
        4 => '900',
        5 => 'regular',
      ),
    ),
    'Noto Serif' => array(
       'family' => 'Noto Serif',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Noto Serif JP' => array(
       'family' => 'Noto Serif JP',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '500',
        3 => '600',
        4 => '700',
        5 => '900',
        6 => 'regular',
      ),
    ),
    'Noto Serif KR' => array(
       'family' => 'Noto Serif KR',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '500',
        3 => '600',
        4 => '700',
        5 => '900',
        6 => 'regular',
      ),
    ),
    'Nova Cut' => array(
       'family' => 'Nova Cut',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Nova Flat' => array(
       'family' => 'Nova Flat',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Nova Mono' => array(
       'family' => 'Nova Mono',
       'category' => 'monospace',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Nova Oval' => array(
       'family' => 'Nova Oval',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Nova Round' => array(
       'family' => 'Nova Round',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Nova Script' => array(
       'family' => 'Nova Script',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Nova Slim' => array(
       'family' => 'Nova Slim',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Nova Square' => array(
       'family' => 'Nova Square',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Numans' => array(
       'family' => 'Numans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Nunito' => array(
       'family' => 'Nunito',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '200italic',
        2 => '300',
        3 => '300italic',
        4 => '600',
        5 => '600italic',
        6 => '700',
        7 => '700italic',
        8 => '800',
        9 => '800italic',
        10 => '900',
        11 => '900italic',
        12 => 'italic',
        13 => 'regular',
      ),
    ),
    'Nunito Sans' => array(
       'family' => 'Nunito Sans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '200italic',
        2 => '300',
        3 => '300italic',
        4 => '600',
        5 => '600italic',
        6 => '700',
        7 => '700italic',
        8 => '800',
        9 => '800italic',
        10 => '900',
        11 => '900italic',
        12 => 'italic',
        13 => 'regular',
      ),
    ),
    'Odor Mean Chey' => array(
       'family' => 'Odor Mean Chey',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Offside' => array(
       'family' => 'Offside',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Old Standard TT' => array(
       'family' => 'Old Standard TT',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'italic',
        2 => 'regular',
      ),
    ),
    'Oldenburg' => array(
       'family' => 'Oldenburg',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Oleo Script' => array(
       'family' => 'Oleo Script',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Oleo Script Swash Caps' => array(
       'family' => 'Oleo Script Swash Caps',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Open Sans' => array(
       'family' => 'Open Sans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '300italic',
        2 => '600',
        3 => '600italic',
        4 => '700',
        5 => '700italic',
        6 => '800',
        7 => '800italic',
        8 => 'italic',
        9 => 'regular',
      ),
    ),
    'Open Sans Condensed' => array(
       'family' => 'Open Sans Condensed',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '300italic',
        2 => '700',
      ),
    ),
    'Oranienbaum' => array(
       'family' => 'Oranienbaum',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Orbitron' => array(
       'family' => 'Orbitron',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '500',
        1 => '700',
        2 => '900',
        3 => 'regular',
      ),
    ),
    'Oregano' => array(
       'family' => 'Oregano',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'Orienta' => array(
       'family' => 'Orienta',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Original Surfer' => array(
       'family' => 'Original Surfer',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Oswald' => array(
       'family' => 'Oswald',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '500',
        3 => '600',
        4 => '700',
        5 => 'regular',
      ),
    ),
    'Over the Rainbow' => array(
       'family' => 'Over the Rainbow',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Overlock' => array(
       'family' => 'Overlock',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => '900',
        3 => '900italic',
        4 => 'italic',
        5 => 'regular',
      ),
    ),
    'Overlock SC' => array(
       'family' => 'Overlock SC',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Overpass' => array(
       'family' => 'Overpass',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '600',
        7 => '600italic',
        8 => '700',
        9 => '700italic',
        10 => '800',
        11 => '800italic',
        12 => '900',
        13 => '900italic',
        14 => 'italic',
        15 => 'regular',
      ),
    ),
    'Overpass Mono' => array(
       'family' => 'Overpass Mono',
       'category' => 'monospace',
       'variants' =>
     array (
        0 => '300',
        1 => '600',
        2 => '700',
        3 => 'regular',
      ),
    ),
    'Ovo' => array(
       'family' => 'Ovo',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Oxygen' => array(
       'family' => 'Oxygen',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '700',
        2 => 'regular',
      ),
    ),
    'Oxygen Mono' => array(
       'family' => 'Oxygen Mono',
       'category' => 'monospace',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'PT Mono' => array(
       'family' => 'PT Mono',
       'category' => 'monospace',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'PT Sans' => array(
       'family' => 'PT Sans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'PT Sans Caption' => array(
       'family' => 'PT Sans Caption',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'PT Sans Narrow' => array(
       'family' => 'PT Sans Narrow',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'PT Serif' => array(
       'family' => 'PT Serif',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'PT Serif Caption' => array(
       'family' => 'PT Serif Caption',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'Pacifico' => array(
       'family' => 'Pacifico',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Padauk' => array(
       'family' => 'Padauk',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Palanquin' => array(
       'family' => 'Palanquin',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '200',
        2 => '300',
        3 => '500',
        4 => '600',
        5 => '700',
        6 => 'regular',
      ),
    ),
    'Palanquin Dark' => array(
       'family' => 'Palanquin Dark',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '500',
        1 => '600',
        2 => '700',
        3 => 'regular',
      ),
    ),
    'Pangolin' => array(
       'family' => 'Pangolin',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Paprika' => array(
       'family' => 'Paprika',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Parisienne' => array(
       'family' => 'Parisienne',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Passero One' => array(
       'family' => 'Passero One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Passion One' => array(
       'family' => 'Passion One',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => '900',
        2 => 'regular',
      ),
    ),
    'Pathway Gothic One' => array(
       'family' => 'Pathway Gothic One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Patrick Hand' => array(
       'family' => 'Patrick Hand',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Patrick Hand SC' => array(
       'family' => 'Patrick Hand SC',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Pattaya' => array(
       'family' => 'Pattaya',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Patua One' => array(
       'family' => 'Patua One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Pavanam' => array(
       'family' => 'Pavanam',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Paytone One' => array(
       'family' => 'Paytone One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Peddana' => array(
       'family' => 'Peddana',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Peralta' => array(
       'family' => 'Peralta',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Permanent Marker' => array(
       'family' => 'Permanent Marker',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Petit Formal Script' => array(
       'family' => 'Petit Formal Script',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Petrona' => array(
       'family' => 'Petrona',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Philosopher' => array(
       'family' => 'Philosopher',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Piedra' => array(
       'family' => 'Piedra',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Pinyon Script' => array(
       'family' => 'Pinyon Script',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Pirata One' => array(
       'family' => 'Pirata One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Plaster' => array(
       'family' => 'Plaster',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Play' => array(
       'family' => 'Play',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Playball' => array(
       'family' => 'Playball',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Playfair Display' => array(
       'family' => 'Playfair Display',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => '900',
        3 => '900italic',
        4 => 'italic',
        5 => 'regular',
      ),
    ),
    'Playfair Display SC' => array(
       'family' => 'Playfair Display SC',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => '900',
        3 => '900italic',
        4 => 'italic',
        5 => 'regular',
      ),
    ),
    'Podkova' => array(
       'family' => 'Podkova',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '500',
        1 => '600',
        2 => '700',
        3 => '800',
        4 => 'regular',
      ),
    ),
    'Poiret One' => array(
       'family' => 'Poiret One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Poller One' => array(
       'family' => 'Poller One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Poly' => array(
       'family' => 'Poly',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'Pompiere' => array(
       'family' => 'Pompiere',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Pontano Sans' => array(
       'family' => 'Pontano Sans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Poor Story' => array(
       'family' => 'Poor Story',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Poppins' => array(
       'family' => 'Poppins',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => '800',
        13 => '800italic',
        14 => '900',
        15 => '900italic',
        16 => 'italic',
        17 => 'regular',
      ),
    ),
    'Port Lligat Sans' => array(
       'family' => 'Port Lligat Sans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Port Lligat Slab' => array(
       'family' => 'Port Lligat Slab',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Pragati Narrow' => array(
       'family' => 'Pragati Narrow',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Prata' => array(
       'family' => 'Prata',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Preahvihear' => array(
       'family' => 'Preahvihear',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Press Start 2P' => array(
       'family' => 'Press Start 2P',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Pridi' => array(
       'family' => 'Pridi',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '500',
        3 => '600',
        4 => '700',
        5 => 'regular',
      ),
    ),
    'Princess Sofia' => array(
       'family' => 'Princess Sofia',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Prociono' => array(
       'family' => 'Prociono',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Prompt' => array(
       'family' => 'Prompt',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => '800',
        13 => '800italic',
        14 => '900',
        15 => '900italic',
        16 => 'italic',
        17 => 'regular',
      ),
    ),
    'Prosto One' => array(
       'family' => 'Prosto One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Proza Libre' => array(
       'family' => 'Proza Libre',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '500',
        1 => '500italic',
        2 => '600',
        3 => '600italic',
        4 => '700',
        5 => '700italic',
        6 => '800',
        7 => '800italic',
        8 => 'italic',
        9 => 'regular',
      ),
    ),
    'Puritan' => array(
       'family' => 'Puritan',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Purple Purse' => array(
       'family' => 'Purple Purse',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Quando' => array(
       'family' => 'Quando',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Quantico' => array(
       'family' => 'Quantico',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Quattrocento' => array(
       'family' => 'Quattrocento',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Quattrocento Sans' => array(
       'family' => 'Quattrocento Sans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Questrial' => array(
       'family' => 'Questrial',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Quicksand' => array(
       'family' => 'Quicksand',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '700',
        3 => 'regular',
      ),
    ),
    'Quintessential' => array(
       'family' => 'Quintessential',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Qwigley' => array(
       'family' => 'Qwigley',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Racing Sans One' => array(
       'family' => 'Racing Sans One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Radley' => array(
       'family' => 'Radley',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'Rajdhani' => array(
       'family' => 'Rajdhani',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '600',
        3 => '700',
        4 => 'regular',
      ),
    ),
    'Rakkas' => array(
       'family' => 'Rakkas',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Raleway' => array(
       'family' => 'Raleway',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => '800',
        13 => '800italic',
        14 => '900',
        15 => '900italic',
        16 => 'italic',
        17 => 'regular',
      ),
    ),
    'Raleway Dots' => array(
       'family' => 'Raleway Dots',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Ramabhadra' => array(
       'family' => 'Ramabhadra',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Ramaraja' => array(
       'family' => 'Ramaraja',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Rambla' => array(
       'family' => 'Rambla',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Rammetto One' => array(
       'family' => 'Rammetto One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Ranchers' => array(
       'family' => 'Ranchers',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Rancho' => array(
       'family' => 'Rancho',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Ranga' => array(
       'family' => 'Ranga',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Rasa' => array(
       'family' => 'Rasa',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '600',
        3 => '700',
        4 => 'regular',
      ),
    ),
    'Rationale' => array(
       'family' => 'Rationale',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Ravi Prakash' => array(
       'family' => 'Ravi Prakash',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Redressed' => array(
       'family' => 'Redressed',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Reem Kufi' => array(
       'family' => 'Reem Kufi',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Reenie Beanie' => array(
       'family' => 'Reenie Beanie',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Revalia' => array(
       'family' => 'Revalia',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Rhodium Libre' => array(
       'family' => 'Rhodium Libre',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Ribeye' => array(
       'family' => 'Ribeye',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Ribeye Marrow' => array(
       'family' => 'Ribeye Marrow',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Righteous' => array(
       'family' => 'Righteous',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Risque' => array(
       'family' => 'Risque',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Roboto' => array(
       'family' => 'Roboto',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '300',
        3 => '300italic',
        4 => '500',
        5 => '500italic',
        6 => '700',
        7 => '700italic',
        8 => '900',
        9 => '900italic',
        10 => 'italic',
        11 => 'regular',
      ),
    ),
    'Roboto Condensed' => array(
       'family' => 'Roboto Condensed',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '300italic',
        2 => '700',
        3 => '700italic',
        4 => 'italic',
        5 => 'regular',
      ),
    ),
    'Roboto Mono' => array(
       'family' => 'Roboto Mono',
       'category' => 'monospace',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '300',
        3 => '300italic',
        4 => '500',
        5 => '500italic',
        6 => '700',
        7 => '700italic',
        8 => 'italic',
        9 => 'regular',
      ),
    ),
    'Roboto Slab' => array(
       'family' => 'Roboto Slab',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '100',
        1 => '300',
        2 => '700',
        3 => 'regular',
      ),
    ),
    'Rochester' => array(
       'family' => 'Rochester',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Rock Salt' => array(
       'family' => 'Rock Salt',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Rokkitt' => array(
       'family' => 'Rokkitt',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '100',
        1 => '200',
        2 => '300',
        3 => '500',
        4 => '600',
        5 => '700',
        6 => '800',
        7 => '900',
        8 => 'regular',
      ),
    ),
    'Romanesco' => array(
       'family' => 'Romanesco',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Ropa Sans' => array(
       'family' => 'Ropa Sans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'Rosario' => array(
       'family' => 'Rosario',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Rosarivo' => array(
       'family' => 'Rosarivo',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'Rouge Script' => array(
       'family' => 'Rouge Script',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Rozha One' => array(
       'family' => 'Rozha One',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Rubik' => array(
       'family' => 'Rubik',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '300italic',
        2 => '500',
        3 => '500italic',
        4 => '700',
        5 => '700italic',
        6 => '900',
        7 => '900italic',
        8 => 'italic',
        9 => 'regular',
      ),
    ),
    'Rubik Mono One' => array(
       'family' => 'Rubik Mono One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Ruda' => array(
       'family' => 'Ruda',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '900',
        2 => 'regular',
      ),
    ),
    'Rufina' => array(
       'family' => 'Rufina',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Ruge Boogie' => array(
       'family' => 'Ruge Boogie',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Ruluko' => array(
       'family' => 'Ruluko',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Rum Raisin' => array(
       'family' => 'Rum Raisin',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Ruslan Display' => array(
       'family' => 'Ruslan Display',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Russo One' => array(
       'family' => 'Russo One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Ruthie' => array(
       'family' => 'Ruthie',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Rye' => array(
       'family' => 'Rye',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sacramento' => array(
       'family' => 'Sacramento',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sahitya' => array(
       'family' => 'Sahitya',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Sail' => array(
       'family' => 'Sail',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Saira' => array(
       'family' => 'Saira',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '200',
        2 => '300',
        3 => '500',
        4 => '600',
        5 => '700',
        6 => '800',
        7 => '900',
        8 => 'regular',
      ),
    ),
    'Saira Condensed' => array(
       'family' => 'Saira Condensed',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '200',
        2 => '300',
        3 => '500',
        4 => '600',
        5 => '700',
        6 => '800',
        7 => '900',
        8 => 'regular',
      ),
    ),
    'Saira Extra Condensed' => array(
       'family' => 'Saira Extra Condensed',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '200',
        2 => '300',
        3 => '500',
        4 => '600',
        5 => '700',
        6 => '800',
        7 => '900',
        8 => 'regular',
      ),
    ),
    'Saira Semi Condensed' => array(
       'family' => 'Saira Semi Condensed',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '200',
        2 => '300',
        3 => '500',
        4 => '600',
        5 => '700',
        6 => '800',
        7 => '900',
        8 => 'regular',
      ),
    ),
    'Salsa' => array(
       'family' => 'Salsa',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sanchez' => array(
       'family' => 'Sanchez',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'Sancreek' => array(
       'family' => 'Sancreek',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sansita' => array(
       'family' => 'Sansita',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => '800',
        3 => '800italic',
        4 => '900',
        5 => '900italic',
        6 => 'italic',
        7 => 'regular',
      ),
    ),
    'Sarala' => array(
       'family' => 'Sarala',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Sarina' => array(
       'family' => 'Sarina',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sarpanch' => array(
       'family' => 'Sarpanch',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '500',
        1 => '600',
        2 => '700',
        3 => '800',
        4 => '900',
        5 => 'regular',
      ),
    ),
    'Satisfy' => array(
       'family' => 'Satisfy',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sawarabi Gothic' => array(
       'family' => 'Sawarabi Gothic',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sawarabi Mincho' => array(
       'family' => 'Sawarabi Mincho',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Scada' => array(
       'family' => 'Scada',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Scheherazade' => array(
       'family' => 'Scheherazade',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Schoolbell' => array(
       'family' => 'Schoolbell',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Scope One' => array(
       'family' => 'Scope One',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Seaweed Script' => array(
       'family' => 'Seaweed Script',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Secular One' => array(
       'family' => 'Secular One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sedgwick Ave' => array(
       'family' => 'Sedgwick Ave',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sedgwick Ave Display' => array(
       'family' => 'Sedgwick Ave Display',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sevillana' => array(
       'family' => 'Sevillana',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Seymour One' => array(
       'family' => 'Seymour One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Shadows Into Light' => array(
       'family' => 'Shadows Into Light',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Shadows Into Light Two' => array(
       'family' => 'Shadows Into Light Two',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Shanti' => array(
       'family' => 'Shanti',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Share' => array(
       'family' => 'Share',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Share Tech' => array(
       'family' => 'Share Tech',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Share Tech Mono' => array(
       'family' => 'Share Tech Mono',
       'category' => 'monospace',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Shojumaru' => array(
       'family' => 'Shojumaru',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Short Stack' => array(
       'family' => 'Short Stack',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Shrikhand' => array(
       'family' => 'Shrikhand',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Siemreap' => array(
       'family' => 'Siemreap',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sigmar One' => array(
       'family' => 'Sigmar One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Signika' => array(
       'family' => 'Signika',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '600',
        2 => '700',
        3 => 'regular',
      ),
    ),
    'Signika Negative' => array(
       'family' => 'Signika Negative',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '600',
        2 => '700',
        3 => 'regular',
      ),
    ),
    'Simonetta' => array(
       'family' => 'Simonetta',
       'category' => 'display',
       'variants' =>
     array (
        0 => '900',
        1 => '900italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Sintony' => array(
       'family' => 'Sintony',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Sirin Stencil' => array(
       'family' => 'Sirin Stencil',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Six Caps' => array(
       'family' => 'Six Caps',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Skranji' => array(
       'family' => 'Skranji',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Slabo 13px' => array(
       'family' => 'Slabo 13px',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Slabo 27px' => array(
       'family' => 'Slabo 27px',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Slackey' => array(
       'family' => 'Slackey',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Smokum' => array(
       'family' => 'Smokum',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Smythe' => array(
       'family' => 'Smythe',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sniglet' => array(
       'family' => 'Sniglet',
       'category' => 'display',
       'variants' =>
     array (
        0 => '800',
        1 => 'regular',
      ),
    ),
    'Snippet' => array(
       'family' => 'Snippet',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Snowburst One' => array(
       'family' => 'Snowburst One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sofadi One' => array(
       'family' => 'Sofadi One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sofia' => array(
       'family' => 'Sofia',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Song Myung' => array(
       'family' => 'Song Myung',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sonsie One' => array(
       'family' => 'Sonsie One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sorts Mill Goudy' => array(
       'family' => 'Sorts Mill Goudy',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'italic',
        1 => 'regular',
      ),
    ),
    'Source Code Pro' => array(
       'family' => 'Source Code Pro',
       'category' => 'monospace',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '500',
        3 => '600',
        4 => '700',
        5 => '900',
        6 => 'regular',
      ),
    ),
    'Source Sans Pro' => array(
       'family' => 'Source Sans Pro',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '200italic',
        2 => '300',
        3 => '300italic',
        4 => '600',
        5 => '600italic',
        6 => '700',
        7 => '700italic',
        8 => '900',
        9 => '900italic',
        10 => 'italic',
        11 => 'regular',
      ),
    ),
    'Source Serif Pro' => array(
       'family' => 'Source Serif Pro',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '600',
        1 => '700',
        2 => 'regular',
      ),
    ),
    'Space Mono' => array(
       'family' => 'Space Mono',
       'category' => 'monospace',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Special Elite' => array(
       'family' => 'Special Elite',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Spectral' => array(
       'family' => 'Spectral',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '200',
        1 => '200italic',
        2 => '300',
        3 => '300italic',
        4 => '500',
        5 => '500italic',
        6 => '600',
        7 => '600italic',
        8 => '700',
        9 => '700italic',
        10 => '800',
        11 => '800italic',
        12 => 'italic',
        13 => 'regular',
      ),
    ),
    'Spectral SC' => array(
       'family' => 'Spectral SC',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '200',
        1 => '200italic',
        2 => '300',
        3 => '300italic',
        4 => '500',
        5 => '500italic',
        6 => '600',
        7 => '600italic',
        8 => '700',
        9 => '700italic',
        10 => '800',
        11 => '800italic',
        12 => 'italic',
        13 => 'regular',
      ),
    ),
    'Spicy Rice' => array(
       'family' => 'Spicy Rice',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Spinnaker' => array(
       'family' => 'Spinnaker',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Spirax' => array(
       'family' => 'Spirax',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Squada One' => array(
       'family' => 'Squada One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sree Krushnadevaraya' => array(
       'family' => 'Sree Krushnadevaraya',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sriracha' => array(
       'family' => 'Sriracha',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Stalemate' => array(
       'family' => 'Stalemate',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Stalinist One' => array(
       'family' => 'Stalinist One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Stardos Stencil' => array(
       'family' => 'Stardos Stencil',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Stint Ultra Condensed' => array(
       'family' => 'Stint Ultra Condensed',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Stint Ultra Expanded' => array(
       'family' => 'Stint Ultra Expanded',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Stoke' => array(
       'family' => 'Stoke',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '300',
        1 => 'regular',
      ),
    ),
    'Strait' => array(
       'family' => 'Strait',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Stylish' => array(
       'family' => 'Stylish',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sue Ellen Francisco' => array(
       'family' => 'Sue Ellen Francisco',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Suez One' => array(
       'family' => 'Suez One',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sumana' => array(
       'family' => 'Sumana',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Sunflower' => array(
       'family' => 'Sunflower',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '700',
      ),
    ),
    'Sunshiney' => array(
       'family' => 'Sunshiney',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Supermercado One' => array(
       'family' => 'Supermercado One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Sura' => array(
       'family' => 'Sura',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Suranna' => array(
       'family' => 'Suranna',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Suravaram' => array(
       'family' => 'Suravaram',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Suwannaphum' => array(
       'family' => 'Suwannaphum',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Swanky and Moo Moo' => array(
       'family' => 'Swanky and Moo Moo',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Syncopate' => array(
       'family' => 'Syncopate',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Tajawal' => array(
       'family' => 'Tajawal',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '500',
        3 => '700',
        4 => '800',
        5 => '900',
        6 => 'regular',
      ),
    ),
    'Tangerine' => array(
       'family' => 'Tangerine',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Taprom' => array(
       'family' => 'Taprom',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Tauri' => array(
       'family' => 'Tauri',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Taviraj' => array(
       'family' => 'Taviraj',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => '800',
        13 => '800italic',
        14 => '900',
        15 => '900italic',
        16 => 'italic',
        17 => 'regular',
      ),
    ),
    'Teko' => array(
       'family' => 'Teko',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '600',
        3 => '700',
        4 => 'regular',
      ),
    ),
    'Telex' => array(
       'family' => 'Telex',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Tenali Ramakrishna' => array(
       'family' => 'Tenali Ramakrishna',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Tenor Sans' => array(
       'family' => 'Tenor Sans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Text Me One' => array(
       'family' => 'Text Me One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'The Girl Next Door' => array(
       'family' => 'The Girl Next Door',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Tienne' => array(
       'family' => 'Tienne',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => '900',
        2 => 'regular',
      ),
    ),
    'Tillana' => array(
       'family' => 'Tillana',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => '500',
        1 => '600',
        2 => '700',
        3 => '800',
        4 => 'regular',
      ),
    ),
    'Timmana' => array(
       'family' => 'Timmana',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Tinos' => array(
       'family' => 'Tinos',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Titan One' => array(
       'family' => 'Titan One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Titillium Web' => array(
       'family' => 'Titillium Web',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '200italic',
        2 => '300',
        3 => '300italic',
        4 => '600',
        5 => '600italic',
        6 => '700',
        7 => '700italic',
        8 => '900',
        9 => 'italic',
        10 => 'regular',
      ),
    ),
    'Trade Winds' => array(
       'family' => 'Trade Winds',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Trirong' => array(
       'family' => 'Trirong',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => '500',
        7 => '500italic',
        8 => '600',
        9 => '600italic',
        10 => '700',
        11 => '700italic',
        12 => '800',
        13 => '800italic',
        14 => '900',
        15 => '900italic',
        16 => 'italic',
        17 => 'regular',
      ),
    ),
    'Trocchi' => array(
       'family' => 'Trocchi',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Trochut' => array(
       'family' => 'Trochut',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => 'italic',
        2 => 'regular',
      ),
    ),
    'Trykker' => array(
       'family' => 'Trykker',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Tulpen One' => array(
       'family' => 'Tulpen One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Ubuntu' => array(
       'family' => 'Ubuntu',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '300',
        1 => '300italic',
        2 => '500',
        3 => '500italic',
        4 => '700',
        5 => '700italic',
        6 => 'italic',
        7 => 'regular',
      ),
    ),
    'Ubuntu Condensed' => array(
       'family' => 'Ubuntu Condensed',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Ubuntu Mono' => array(
       'family' => 'Ubuntu Mono',
       'category' => 'monospace',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Ultra' => array(
       'family' => 'Ultra',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Uncial Antiqua' => array(
       'family' => 'Uncial Antiqua',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Underdog' => array(
       'family' => 'Underdog',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Unica One' => array(
       'family' => 'Unica One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'UnifrakturCook' => array(
       'family' => 'UnifrakturCook',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
      ),
    ),
    'UnifrakturMaguntia' => array(
       'family' => 'UnifrakturMaguntia',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Unkempt' => array(
       'family' => 'Unkempt',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
    'Unlock' => array(
       'family' => 'Unlock',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Unna' => array(
       'family' => 'Unna',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'VT323' => array(
       'family' => 'VT323',
       'category' => 'monospace',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Vampiro One' => array(
       'family' => 'Vampiro One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Varela' => array(
       'family' => 'Varela',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Varela Round' => array(
       'family' => 'Varela Round',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Vast Shadow' => array(
       'family' => 'Vast Shadow',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Vesper Libre' => array(
       'family' => 'Vesper Libre',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '500',
        1 => '700',
        2 => '900',
        3 => 'regular',
      ),
    ),
    'Vibur' => array(
       'family' => 'Vibur',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Vidaloka' => array(
       'family' => 'Vidaloka',
       'category' => 'serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Viga' => array(
       'family' => 'Viga',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Voces' => array(
       'family' => 'Voces',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Volkhov' => array(
       'family' => 'Volkhov',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '700',
        1 => '700italic',
        2 => 'italic',
        3 => 'regular',
      ),
    ),
    'Vollkorn' => array(
       'family' => 'Vollkorn',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '600',
        1 => '600italic',
        2 => '700',
        3 => '700italic',
        4 => '900',
        5 => '900italic',
        6 => 'italic',
        7 => 'regular',
      ),
    ),
    'Vollkorn SC' => array(
       'family' => 'Vollkorn SC',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '600',
        1 => '700',
        2 => '900',
        3 => 'regular',
      ),
    ),
    'Voltaire' => array(
       'family' => 'Voltaire',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Waiting for the Sunrise' => array(
       'family' => 'Waiting for the Sunrise',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Wallpoet' => array(
       'family' => 'Wallpoet',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Walter Turncoat' => array(
       'family' => 'Walter Turncoat',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Warnes' => array(
       'family' => 'Warnes',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Wellfleet' => array(
       'family' => 'Wellfleet',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Wendy One' => array(
       'family' => 'Wendy One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Wire One' => array(
       'family' => 'Wire One',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Work Sans' => array(
       'family' => 'Work Sans',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '200',
        2 => '300',
        3 => '500',
        4 => '600',
        5 => '700',
        6 => '800',
        7 => '900',
        8 => 'regular',
      ),
    ),
    'Yanone Kaffeesatz' => array(
       'family' => 'Yanone Kaffeesatz',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '200',
        1 => '300',
        2 => '700',
        3 => 'regular',
      ),
    ),
    'Yantramanav' => array(
       'family' => 'Yantramanav',
       'category' => 'sans-serif',
       'variants' =>
     array (
        0 => '100',
        1 => '300',
        2 => '500',
        3 => '700',
        4 => '900',
        5 => 'regular',
      ),
    ),
    'Yatra One' => array(
       'family' => 'Yatra One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Yellowtail' => array(
       'family' => 'Yellowtail',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Yeon Sung' => array(
       'family' => 'Yeon Sung',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Yeseva One' => array(
       'family' => 'Yeseva One',
       'category' => 'display',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Yesteryear' => array(
       'family' => 'Yesteryear',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Yrsa' => array(
       'family' => 'Yrsa',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '300',
        1 => '500',
        2 => '600',
        3 => '700',
        4 => 'regular',
      ),
    ),
    'Zeyada' => array(
       'family' => 'Zeyada',
       'category' => 'handwriting',
       'variants' =>
     array (
        0 => 'regular',
      ),
    ),
    'Zilla Slab' => array(
       'family' => 'Zilla Slab',
       'category' => 'serif',
       'variants' =>
     array (
        0 => '300',
        1 => '300italic',
        2 => '500',
        3 => '500italic',
        4 => '600',
        5 => '600italic',
        6 => '700',
        7 => '700italic',
        8 => 'italic',
        9 => 'regular',
      ),
    ),
    'Zilla Slab Highlight' => array(
       'family' => 'Zilla Slab Highlight',
       'category' => 'display',
       'variants' =>
     array (
        0 => '700',
        1 => 'regular',
      ),
    ),
);