<div class="dsvy-ihbox-box d-flex">
	<?php echo dsvy_esc_kses( $icon_html ); ?>
	<div class="dsvy-ihbox-contents">
		<?php echo dsvy_esc_kses( $subtitle_html ); ?>
		<?php echo dsvy_esc_kses( $title_html ); ?>		
		<?php echo dsvy_esc_kses($desc_html); ?>
		<?php echo dsvy_esc_kses($button_html); ?>
	</div><!-- .dsvy-ihbox-contents -->
</div>
