
<div class="d-flex">
    <?php echo dsvy_esc_kses( $box_number_html ); ?>
	<?php echo dsvy_esc_kses( $title_html ); ?>
</div>
<div class="dsvy-ihbox-contents">		
	<?php echo dsvy_esc_kses( $subtitle_html ); ?>
	<?php echo dsvy_esc_kses($desc_html); ?>
	<?php echo dsvy_esc_kses($button_html); ?>
</div><!-- .dsvy-ihbox-contents -->
