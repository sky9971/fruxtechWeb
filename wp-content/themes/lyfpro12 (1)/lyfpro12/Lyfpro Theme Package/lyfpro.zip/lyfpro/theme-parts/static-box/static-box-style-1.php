<div class="dsvy-imgbox">
	<?php echo dsvy_esc_kses($image_html); ?>
</div>
<div class="dsvy-contentbox">
	<?php echo dsvy_esc_kses($label_html); ?>
	<?php echo dsvy_esc_kses($smalltext_html); ?>
</div>